<?php

//pagina p verificar se o usuario esta logado
require_once(__DIR__ . "/../../controller/LoginController.php");


$loginCont = new LoginController();
if(! $loginCont->usuarioEstaLogado()) {
    //redirecionar para o login
    header("location: " . BASE_URL . "/view/login/login.php");
    exit;
}